//
//  TestStruct.swift
//  TestApp
//
//  Created by Alexander Skvortsov on 14/11/2016.
//  Copyright © 2016 Test. All rights reserved.
//

import Foundation

public struct TestStruct {
  public init() {}
}
